"""Manage IT helpdesk tickets and persist them as JSON."""

import hmac
import ipaddress
import json
import os
import platform
import shutil
import subprocess
from datetime import datetime
from getpass import getpass


class Helpdesk:
    """Keep ticket state and audit history for one helpdesk instance."""

    def __init__(self):
        self.tickets = {}
        self.ticket_counter = 100
        self.audit_trail = []

    def raise_ticket(self, user, issue_type, urgency="3", audit_trail=None):
        """Create a ticket with an integer priority from one to five."""
        priority = int(urgency)
        if not 1 <= priority <= 5:
            raise ValueError("Urgency must be between 1 and 5")
        self.ticket_counter += 1
        self.tickets[self.ticket_counter] = {
            "user": user, "issue": issue_type, "priority": priority,
            "tech": None, "notes": [],
        }
        entry = f"{user} raised #{self.ticket_counter} at {datetime.now()}"
        self.audit_trail.append(entry)
        if audit_trail is not None:
            audit_trail.append(entry)
        return self.ticket_counter

    def assign_ticket(self, ticket_id, technician):
        """Assign an existing ticket."""
        self.tickets[ticket_id]["tech"] = technician

    def add_note(self, ticket_id, note):
        """Return false when the ticket does not exist."""
        if ticket_id not in self.tickets:
            return False
        self.tickets[ticket_id]["notes"].append(note)
        return True

    def close_ticket(self, ticket_id, password):
        """Close an existing ticket only with configured credentials."""
        expected = os.environ.get("HELPDESK_ADMIN_PASSWORD")
        if not expected or not hmac.compare_digest(
                password.encode(), expected.encode()
        ):
            return False
        return self.tickets.pop(ticket_id, None) is not None

    def unresolved_high_priority(self):
        """List unassigned tickets with priority four or five."""
        return [
            key for key, ticket in self.tickets.items()
            if ticket["priority"] >= 4 and ticket["tech"] is None
        ]

    def save_tickets(self, filename="tickets.json"):
        """Write current ticket state to a JSON file."""
        with open(filename, "w", encoding="utf-8") as stream:
            json.dump(self.tickets, stream, indent=2)


def ping_user_machine(hostname):
    """Ping a validated IP address without invoking a shell."""
    address = str(ipaddress.ip_address(hostname))
    executable = shutil.which("ping")
    if executable is None:
        raise FileNotFoundError("ping executable is unavailable")
    flag = "-n" if platform.system() == "Windows" else "-c"
    return subprocess.run(
        [executable, flag, "1", address], check=False, timeout=10
    ).returncode


def main():
    """Demonstrate ticket creation, assignment and persistence."""
    desk = Helpdesk()
    first = desk.raise_ticket("anil", "printer", "5")
    desk.raise_ticket("meera", "wifi", "4")
    third = desk.raise_ticket("joe", "vpn", "3")
    desk.assign_ticket(first, "Tech-Kiran")
    if not desk.add_note(999, "Called user"):
        print("Ticket 999 not found")
    print("Unassigned high priority:", desk.unresolved_high_priority())
    while True:
        level = input(
            "Urgency for a new laptop ticket (1-5, Enter for 3): "
        )
        try:
            desk.raise_ticket("sana", "laptop", level or "3")
            break
        except ValueError:
            print("Enter an integer between 1 and 5.")
    if os.environ.get("HELPDESK_ADMIN_PASSWORD"):
        if not desk.close_ticket(third, getpass("Admin password: ")):
            print("Ticket not closed: authorization failed")
    else:
        print("Admin password not configured; ticket remains open")
    desk.save_tickets()
    print("Open tickets:", list(desk.tickets))


if __name__ == "__main__":
    main()
