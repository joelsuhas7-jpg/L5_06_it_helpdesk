# Lab 5 — IT Helpdesk Ticket Allocator

Manual review of the original source; analyzer results are not yet verified.

| Issue | Type | Original line(s) | Description | Fix approach |
|---|---|---|---|---|
| Shell injection | Security / high | 37–38 | Untrusted hostname concatenated into shell command | Validate IP, use argument list without shell, timeout |
| Hardcoded password | Security / medium | 8, 54 | Password embedded in source | Environment configuration, masked prompt, constant-time comparison |
| Invalid urgency | Logic | 13, 48, 52–53 | Negative and out-of-range priorities accepted | Validate 1–5 and retry invalid input |
| Mutable default | Bug | 10, 14 | Audit list shared across calls | None default and instance-owned audit history |
| Bare exception | Quality | 20–24 | All errors silently swallowed | Explicit missing-ticket check and status |
| Global state | Quality | 6–7, 11 | Shared mutable ticket state | Encapsulate in Helpdesk instance |
| Unsafe deletion | Logic | 26–28 | Missing ID raises KeyError | Safe pop and explicit success status |
| Naming / None comparison | Style | 30–34 | Camel case and equality comparison | snake_case and is None |
| File handling | Quality | 40–43 | Manual close and no encoding | Context manager and UTF-8 JSON dump |
| Unused variable | Quality | 47 | t2 never used | Remove assignment |
| Import side effect | Quality | 58 | Main runs on import | Main guard |
| Formatting | Style | 10–14 and throughout | Long lines and insufficient blank lines | PEP 8 formatting and docstrings |

The ping function now accepts IP addresses only, a deliberate restriction to avoid untrusted command arguments. Without configured credentials, closing a ticket fails safely. Bandit may still flag subprocess usage for review; no suppression is applied.
