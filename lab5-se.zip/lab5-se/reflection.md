# Reflection

The supplied handout does not contain the four question texts; the following are inferred reflection prompts.

1. **What did static analysis help identify?** Manual review identified shell injection, hardcoded credentials, shared mutable defaults and formatting problems. The automated analyzers should be run to confirm applicable findings.
2. **How do the tools differ?** Pylint checks code quality and design, Bandit checks security patterns, and Flake8 checks style and selected programming errors.
3. **Which issue was most important?** Shell injection could allow unintended command execution. Passing validated arguments without a shell reduces that risk.
4. **Why rerun tools and tests?** Reanalysis checks whether warnings disappear, while functional tests verify behavior such as validation and authorization that static analysis cannot fully establish.
