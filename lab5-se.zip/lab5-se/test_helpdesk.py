"""Functional checks for the corrected ticket system."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from helpdesk_system import Helpdesk, ping_user_machine


class HelpdeskTests(unittest.TestCase):
    def test_priority(self):
        desk = Helpdesk()
        for value in (-7, 0, 6, 'bad'):
            with self.assertRaises(ValueError):
                desk.raise_ticket('user', 'wifi', value)
        self.assertEqual(desk.raise_ticket('user', 'wifi', 5), 101)

    def test_assignment(self):
        desk = Helpdesk()
        key = desk.raise_ticket('user', 'wifi', 5)
        self.assertEqual(desk.unresolved_high_priority(), [key])
        desk.assign_ticket(key, 'tech')
        self.assertEqual(desk.unresolved_high_priority(), [])

    def test_notes(self):
        desk = Helpdesk()
        key = desk.raise_ticket('user', 'wifi')
        self.assertTrue(desk.add_note(key, 'called'))
        self.assertFalse(desk.add_note(999, 'called'))

    def test_auth(self):
        desk = Helpdesk()
        key = desk.raise_ticket('user', 'wifi')
        with patch.dict('os.environ', {'HELPDESK_ADMIN_PASSWORD': 'test-only'}):
            self.assertFalse(desk.close_ticket(key, 'wrong'))
            self.assertTrue(desk.close_ticket(key, 'test-only'))
            self.assertFalse(desk.close_ticket(key, 'test-only'))

    def test_audit(self):
        first, second = Helpdesk(), Helpdesk()
        first.raise_ticket('user', 'wifi')
        self.assertEqual(len(first.audit_trail), 1)
        self.assertEqual(second.audit_trail, [])

    def test_save(self):
        desk = Helpdesk()
        key = desk.raise_ticket('user', 'wifi')
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'tickets.json'
            desk.save_tickets(path)
            self.assertEqual(json.loads(path.read_text())[str(key)]['priority'], 3)

    def test_ping_rejects_bad_input(self):
        with self.assertRaises(ValueError):
            ping_user_machine('not an IP')


if __name__ == '__main__':
    unittest.main()
