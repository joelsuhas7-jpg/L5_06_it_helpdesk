# Lab 5 — IT Helpdesk Ticket Allocator

Corrected project for the supplied IT Helpdesk assignment.

Run `python helpdesk_system.py`. Set the environment variable `HELPDESK_ADMIN_PASSWORD` to a password of your choice before running if you want to demonstrate authorized closure. The ping helper accepts IPv4/IPv6 addresses only.

Run `python -m unittest -v` for functional tests.

Run `python -m pip install pylint bandit flake8` and `python run_analysis.py` to generate official reports in reports/before and reports/after. Installation was unavailable during preparation, so analyzer scores and findings are not certified. Review remaining warnings, especially subprocess-related Bandit findings, before submitting.

Original code is retained in original/ for baseline analysis; do not deploy it. The three local fix commits are in fix_history.bundle (inspect with `git clone fix_history.bundle history`). No remote repository was modified. The bundle contains code history only; documentation and tests are supplied separately in this ZIP.
