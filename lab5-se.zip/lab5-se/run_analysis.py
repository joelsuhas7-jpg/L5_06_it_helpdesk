"""Generate six genuine analysis reports from the two source versions."""
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TOOLS = ("pylint", "bandit", "flake8")
missing = [tool for tool in TOOLS if importlib.util.find_spec(tool) is None]
if missing:
    sys.exit("Install missing tools: python -m pip install " + " ".join(missing))
for stage, source in (("before", "original/helpdesk_system.py"),
                      ("after", "helpdesk_system.py")):
    folder = ROOT / "reports" / stage
    folder.mkdir(parents=True, exist_ok=True)
    for tool in TOOLS:
        args = [sys.executable, "-m", tool]
        if tool == "bandit":
            args.append("-r")
        args.append(source)
        with (folder / f"{tool}_report.txt").open("w", encoding="utf-8") as out:
            result = subprocess.run(args, cwd=ROOT, stdout=out,
                                    stderr=subprocess.STDOUT, check=False)
        print(stage, tool, "exit code", result.returncode)
